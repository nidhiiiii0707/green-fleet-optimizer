# FINAL OPTIMIZATION REPORT

## What this pipeline does
Real/derived fleet, route, port, and fuel-cost data -> candidate generation ->
hard feasibility screening -> real (un-retrained) XGBoost fuel-consumption
model -> SCENARIO_INPUT cost/GHG conversion -> four optimizers (NSGA-II,
QUBO/simulated-annealing, MO-QIGA, MILP) searching the identical decision
space -> merged Pareto archive -> `final_pareto_fleet_plans.csv`.

Run the whole thing with: `./.venv2/Scripts/python.exe run_optimization_pipeline.py`
(see README.md / NEXT_STEPS.md for full environment setup).

## REAL data used
- Vessel-class speed bounds (min/max/mean knots) — `fleet_parameters.csv` (`ship_performance.csv` observations).
- Port coordinates and the 13-port real route figure — `port_master_derived.csv`, `route_derived.csv` origin.
- Fuel-type categories (DM, RM380) and every operating-condition feature fed to the XGB model — real CPS_Poseidon telemetry (`data/cps_poseidon_sample.csv`, a 300-row real sample used as operating-condition templates).
- The trained fuel model itself — `models/fuel_xgb_pipeline.joblib`, loaded and called, never retrained.

## DERIVED data used
- Route distance (haversine of real port coordinates) and nominal voyage time — `route_derived.csv`.
- Vessel cargo capacity per class = real mean cargo tons / real mean load ratio (`data_layer.py`).
- Voyage fuel = XGB rate prediction x voyage hours (distance/speed) — a DERIVED total built from a real prediction, but the base physical unit is undocumented (see below).

## SCENARIO_INPUT parameters (assumed, not measured)
- Fuel price (USD/tonne) and GHG emission factor (kgCO2/tonne) per fuel type — standard order-of-magnitude/IMO reference values, NOT measured in this dataset.
- Vessel-fuel compatibility matrix, port fuel availability, voyage-deadline multiplier (1.5x nominal), per-route cargo target.
- The 1.0-hour fuel-rate sampling interval assumption (the raw telemetry has no timestamp column at all, so the real interval cannot be recovered from data).

## MODEL PREDICTIONS
- `predicted_fuel_rate` in `final_pareto_fleet_plans.csv` = live call to `fuel_xgb_pipeline.joblib` (test R2 = 0.970 on its own held-out split, per the artifact's stored `test_metrics`). Cargo/load/draft are confirmed NOT model inputs (checked against `models/fuel_pipeline_utils.py` and the artifact's `raw_input_columns`/`engineered_features`).

## OPTIMIZATION OUTPUTS
- `final_pareto_fleet_plans.csv` — merged non-dominated set across NSGA-II, QUBO-SA, MO-QIGA, and exact MILP, all run on the identical 252-candidate / 6-leg prototype scenario, same seed.
- `algorithm_comparison.csv/.md` + `comparison_plots/*.png` — hypervolume (Monte-Carlo, normalized), IGD (vs. union-of-fronts proxy, no true front is known), runtime, feasibility ratio, diversity.
- `robustness_results.csv` / `robustness_report.md` — sensitivity of the NSGA-II front to SCENARIO_INPUT perturbations only.

## LIMITATIONS (read before using any number here for a real decision)
1. **Fuel/Cost/GHG absolute magnitudes are NOT verified real-world accurate.** The XGB
   target's physical unit is undocumented, the sampling interval is an assumption, and
   fuel price / emission factor are SCENARIO_INPUT. Only RELATIVE comparisons between
   candidates/algorithms under this one fixed assumption set are meaningful.
2. **Draft-vs-port-depth and port-capacity constraints are UNAVAILABLE everywhere** — no
   physical port depth (metres) or rated port throughput exists in the processed data. The
   feasibility checker reports this explicitly rather than fabricating a pass/fail.
3. **No individual-vessel DWT exists anywhere** — vessel capacity is a DERIVED
   fleet-segment-level estimate (mean cargo / mean load ratio), not a rated capacity for any
   specific ship.
4. **Route cargo demand is SCENARIO_INPUT** — no real origin-destination tonnage exists for
   the specific synthetic port pairs used (real port coordinates, but no real sailed-track
   traffic between them).
5. **MO-QIGA is a classical simulation of a quantum-inspired heuristic. QUBO here is a
   mathematical formulation solved by classical simulated annealing.** Neither runs on, nor
   claims to run on, quantum hardware anywhere in this repository.
6. **Prototype scale only** — 252 candidates / 6 legs / 4 vessel classes, chosen to keep
   NSGA-II/QUBO/MO-QIGA/MILP runtimes manageable for validation; not a production fleet size.
7. Pre-existing `tests/test_candidate.py`, `test_candidate_evaluation.py`, `test_feasibility.py`,
   `test_fuel_predictor.py`, `test_loaders.py`, `test_objectives.py`, `test_parameter_builder.py`,
   `test_smoke.py` reference a `src.*` package that does not exist in this repo (orphaned from
   an earlier/sibling attempt) and are excluded via `pytest.ini`; they were not authored or
   relied upon by this pipeline.
