import React, { useState } from "react";

interface ReportCard {
  id: string;
  title: string;
  description: string;
  date: string;
  run: string;
  type: "optimization" | "sustainability" | "tradeoff" | "compliance";
  ready: boolean;
}

const REPORTS: ReportCard[] = [
  {
    id: "R01",
    title: "Optimization Report",
    description: "Full summary of MO-QIGA optimization run #024, including Pareto-optimal plans, method performance, constraint satisfaction, and solution comparison.",
    date: "04 Feb 2025", run: "RUN #024",
    type: "optimization", ready: true,
  },
  {
    id: "R02",
    title: "Sustainability Report",
    description: "Lifecycle GHG analysis, fuel mix breakdown (Well-to-Tank, Tank-to-Wake, Well-to-Wake), emissions per cargo unit, and comparison to industry benchmarks.",
    date: "04 Feb 2025", run: "RUN #024",
    type: "sustainability", ready: true,
  },
  {
    id: "R03",
    title: "Trade-off Analysis",
    description: "Comparison of all 18 Pareto-optimal fleet plans across fuel, cost and GHG objectives. Includes sensitivity analysis and decision-support guidance.",
    date: "04 Feb 2025", run: "RUN #024",
    type: "tradeoff", ready: true,
  },
  {
    id: "R04",
    title: "Compliance Report",
    description: "Regulatory compliance status for all active vessel assignments, including EU ETS, IMO GHG targets, port state control requirements, and shore-power usage.",
    date: "04 Feb 2025", run: "RUN #024",
    type: "compliance", ready: true,
  },
];

const TYPE_CONFIG = {
  optimization:  { color: "#7C3AED", bg: "#F5F3FF", label: "Optimization",  icon: "M11 3.055A9.001 9.001 0 1020.945 13H11V3.055z M20.488 9H15V3.512A9.025 9.025 0 0120.488 9z" },
  sustainability:{ color: "#059669", bg: "#F0FDF4", label: "Sustainability", icon: "M5 3l14 9-14 9V3z" },
  tradeoff:      { color: "#1D4ED8", bg: "#EFF6FF", label: "Trade-off",      icon: "M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4" },
  compliance:    { color: "#D97706", bg: "#FFFBEB", label: "Compliance",     icon: "M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" },
};

export default function Reports() {
  const [downloading, setDownloading] = useState<string | null>(null);

  function handleExport(id: string, format: "pdf" | "csv") {
    setDownloading(id + format);
    setTimeout(() => setDownloading(null), 1500);
  }

  return (
    <div style={{ padding: "24px 28px", overflowY: "auto", height: "100%" }}>

      {/* Download data section */}
      <div style={{ background: "white", border: "1px solid #E2E8F0", borderRadius: 10, padding: "16px 20px", marginBottom: 24, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div>
          <div style={{ fontSize: 14, fontWeight: 700, color: "#0F172A", fontFamily: "'DM Sans', sans-serif" }}>Bulk Data Export</div>
          <div style={{ fontSize: 12, color: "#64748B", marginTop: 2 }}>Download raw optimization data, vessel assignments, and constraint logs for RUN #024.</div>
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          {[
            { label: "Pareto Solutions (CSV)", fmt: "csv" },
            { label: "Fleet Assignments (CSV)", fmt: "csv" },
            { label: "Full Report (PDF)", fmt: "pdf" },
          ].map(btn => (
            <button
              key={btn.label}
              onClick={() => handleExport("bulk-" + btn.fmt, btn.fmt as "pdf" | "csv")}
              style={{
                background: downloading === "bulk-" + btn.fmt ? "#059669" : "white",
                color: downloading === "bulk-" + btn.fmt ? "white" : "#475569",
                border: "1px solid #E2E8F0",
                borderRadius: 7, padding: "7px 14px", fontSize: 12, cursor: "pointer", fontWeight: 500,
                transition: "all 0.2s",
              }}
            >
              {downloading === "bulk-" + btn.fmt ? "✓ Preparing..." : "↓ " + btn.label}
            </button>
          ))}
        </div>
      </div>

      {/* Report cards grid */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
        {REPORTS.map(report => {
          const tc = TYPE_CONFIG[report.type];
          return (
            <div key={report.id} style={{ background: "white", border: "1px solid #E2E8F0", borderRadius: 12, overflow: "hidden" }}>
              {/* Card header */}
              <div style={{ background: tc.bg, padding: "18px 20px", borderBottom: "1px solid #F1F5F9" }}>
                <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                  <div style={{ width: 36, height: 36, borderRadius: 8, background: `${tc.color}18`, border: `1px solid ${tc.color}30`, display: "flex", alignItems: "center", justifyContent: "center" }}>
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke={tc.color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d={tc.icon} />
                    </svg>
                  </div>
                  <div>
                    <div style={{ fontSize: 10, color: tc.color, textTransform: "uppercase", letterSpacing: "0.07em", fontWeight: 700 }}>{tc.label}</div>
                    <h3 style={{ margin: 0, fontSize: 15, fontWeight: 700, color: "#0F172A", fontFamily: "'DM Sans', sans-serif" }}>{report.title}</h3>
                  </div>
                </div>
              </div>

              {/* Card body */}
              <div style={{ padding: "16px 20px" }}>
                <p style={{ fontSize: 13, color: "#475569", lineHeight: 1.6, margin: "0 0 14px" }}>{report.description}</p>

                <div style={{ display: "flex", gap: 12, marginBottom: 16, fontSize: 11, color: "#94A3B8" }}>
                  <span>📅 {report.date}</span>
                  <span>⚡ {report.run}</span>
                  {report.ready && <span style={{ color: "#059669", fontWeight: 600 }}>✓ Ready</span>}
                </div>

                <div style={{ display: "flex", gap: 8 }}>
                  <button
                    style={{
                      flex: 1, background: tc.color, color: "white", border: "none",
                      borderRadius: 7, padding: "8px 0", fontSize: 13, fontWeight: 600, cursor: "pointer",
                    }}
                  >
                    View Report
                  </button>
                  <button
                    onClick={() => handleExport(report.id, "pdf")}
                    style={{
                      background: downloading === report.id + "pdf" ? "#059669" : "white",
                      color: downloading === report.id + "pdf" ? "white" : "#475569",
                      border: "1px solid #E2E8F0",
                      borderRadius: 7, padding: "8px 14px", fontSize: 13, cursor: "pointer",
                      transition: "all 0.2s",
                    }}
                  >
                    {downloading === report.id + "pdf" ? "✓" : "↓ PDF"}
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Technical evaluation section */}
      <div style={{ marginTop: 24, background: "white", border: "1px solid #E2E8F0", borderRadius: 10, padding: "18px 20px" }}>
        <div style={{ fontSize: 14, fontWeight: 700, color: "#0F172A", fontFamily: "'DM Sans', sans-serif", marginBottom: 4 }}>Technical Evaluation — Algorithm Performance</div>
        <div style={{ fontSize: 12, color: "#64748B", marginBottom: 16 }}>Comparative performance metrics for technical review.</div>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 16 }}>

          {/* MO-QIGA vs NSGA-II */}
          <div style={{ border: "1px solid #E2E8F0", borderRadius: 8, overflow: "hidden" }}>
            <div style={{ background: "#F5F3FF", padding: "10px 14px", borderBottom: "1px solid #E2E8F0" }}>
              <div style={{ fontSize: 11, fontWeight: 700, color: "#7C3AED" }}>MO-QIGA vs NSGA-II</div>
            </div>
            <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 12 }}>
              <thead><tr style={{ background: "#F8FAFC" }}>
                <th style={{ padding: "7px 10px", textAlign: "left", fontSize: 10, fontWeight: 700, color: "#64748B", borderBottom: "1px solid #F1F5F9" }}>Metric</th>
                <th style={{ padding: "7px 10px", textAlign: "center", fontSize: 10, fontWeight: 700, color: "#7C3AED", borderBottom: "1px solid #F1F5F9" }}>MO-QIGA</th>
                <th style={{ padding: "7px 10px", textAlign: "center", fontSize: 10, fontWeight: 700, color: "#64748B", borderBottom: "1px solid #F1F5F9" }}>NSGA-II</th>
              </tr></thead>
              <tbody>
                {[
                  ["Pareto solutions", "18", "12"],
                  ["Solution quality", "High", "Medium"],
                  ["Diversity index", "0.84", "0.61"],
                  ["Runtime (s)", "252", "418"],
                ].map(([m, a, b], i) => (
                  <tr key={m} style={{ background: i % 2 === 0 ? "white" : "#FAFAFA", borderBottom: "1px solid #F1F5F9" }}>
                    <td style={{ padding: "7px 10px", color: "#64748B" }}>{m}</td>
                    <td style={{ padding: "7px 10px", textAlign: "center", color: "#7C3AED", fontWeight: 600, fontFamily: "'JetBrains Mono', monospace" }}>{a}</td>
                    <td style={{ padding: "7px 10px", textAlign: "center", color: "#94A3B8", fontFamily: "'JetBrains Mono', monospace" }}>{b}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* MILP Comparison */}
          <div style={{ border: "1px solid #E2E8F0", borderRadius: 8, overflow: "hidden" }}>
            <div style={{ background: "#EFF6FF", padding: "10px 14px", borderBottom: "1px solid #E2E8F0" }}>
              <div style={{ fontSize: 11, fontWeight: 700, color: "#1D4ED8" }}>MILP Exact (small instances)</div>
            </div>
            <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 12 }}>
              <thead><tr style={{ background: "#F8FAFC" }}>
                <th style={{ padding: "7px 10px", textAlign: "left", fontSize: 10, fontWeight: 700, color: "#64748B", borderBottom: "1px solid #F1F5F9" }}>Metric</th>
                <th style={{ padding: "7px 10px", textAlign: "center", fontSize: 10, fontWeight: 700, color: "#1D4ED8", borderBottom: "1px solid #F1F5F9" }}>MO-QIGA</th>
                <th style={{ padding: "7px 10px", textAlign: "center", fontSize: 10, fontWeight: 700, color: "#64748B", borderBottom: "1px solid #F1F5F9" }}>MILP</th>
              </tr></thead>
              <tbody>
                {[
                  ["Obj. value (fuel)", "4,820", "4,750"],
                  ["Optimality gap", "1.47%", "—"],
                  ["Runtime (s)", "18", "3,240"],
                  ["Scalable?", "Yes", "No"],
                ].map(([m, a, b], i) => (
                  <tr key={m} style={{ background: i % 2 === 0 ? "white" : "#FAFAFA", borderBottom: "1px solid #F1F5F9" }}>
                    <td style={{ padding: "7px 10px", color: "#64748B" }}>{m}</td>
                    <td style={{ padding: "7px 10px", textAlign: "center", color: "#1D4ED8", fontWeight: 600, fontFamily: "'JetBrains Mono', monospace" }}>{a}</td>
                    <td style={{ padding: "7px 10px", textAlign: "center", color: "#94A3B8", fontFamily: "'JetBrains Mono', monospace" }}>{b}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Scalability */}
          <div style={{ border: "1px solid #E2E8F0", borderRadius: 8, overflow: "hidden" }}>
            <div style={{ background: "#F0FDF4", padding: "10px 14px", borderBottom: "1px solid #E2E8F0" }}>
              <div style={{ fontSize: 11, fontWeight: 700, color: "#059669" }}>Scalability (MO-QIGA)</div>
            </div>
            <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 12 }}>
              <thead><tr style={{ background: "#F8FAFC" }}>
                <th style={{ padding: "7px 10px", textAlign: "left", fontSize: 10, fontWeight: 700, color: "#64748B", borderBottom: "1px solid #F1F5F9" }}>Problem Size</th>
                <th style={{ padding: "7px 10px", textAlign: "center", fontSize: 10, fontWeight: 700, color: "#059669", borderBottom: "1px solid #F1F5F9" }}>Runtime</th>
              </tr></thead>
              <tbody>
                {[
                  ["10 vessels, 5 ports", "8s"],
                  ["20 vessels, 10 ports", "52s"],
                  ["30 vessels, 15 ports", "185s"],
                  ["50 vessels, 20 ports", "~12m"],
                ].map(([size, t], i) => (
                  <tr key={size} style={{ background: i % 2 === 0 ? "white" : "#FAFAFA", borderBottom: "1px solid #F1F5F9" }}>
                    <td style={{ padding: "7px 10px", color: "#64748B" }}>{size}</td>
                    <td style={{ padding: "7px 10px", textAlign: "center", color: "#059669", fontWeight: 600, fontFamily: "'JetBrains Mono', monospace" }}>{t}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
